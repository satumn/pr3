import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Feed cat',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: "Cat's restaurant"),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  double _counter = 0;

  void feedFish() {
    setState(() {
      if (_counter<10){_counter++;}
    });
  }
  void feedMilk() {
    setState(() {
      if (_counter<10){_counter+=0.5;}
    });
  }
  void Cleen() {
    setState(() {
      _counter=0;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Satiety scale $_counter',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            SizedBox(),
            _counter > 5
            ? Image.network(
              "https://cdn0.iconfinder.com/data/icons/cat-pattern/94/cat4-512.png", height: 300, width: 300,
            )
            : Image.network(
              "https://static.thenounproject.com/png/1248334-200.png", height: 340, width: 340,
            ),
         Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            IconButton(onPressed: feedFish, tooltip: '+1', icon: Image.network("https://static.vecteezy.com/system/resources/thumbnails/007/126/419/small/fish-seafood-icon-free-vector.jpg", width: 50, height: 50,)),
            IconButton(onPressed: feedMilk, tooltip: '+0.5', icon: Image.network("https://cdn-icons-png.flaticon.com/512/869/869655.png", width: 60, height: 60,)),
          ],
         ),
        ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: Cleen,
        tooltip: 'Cleen',
        child: const Text('10 hours later'),
      ),
      );
  }
}
