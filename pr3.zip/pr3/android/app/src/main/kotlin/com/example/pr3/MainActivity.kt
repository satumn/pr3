package com.example.pr3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
